package tot.domain;

public class VO {

}
