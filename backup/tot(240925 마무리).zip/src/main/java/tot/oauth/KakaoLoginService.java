package tot.oauth;

import java.io.IOException;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Service
public class KakaoLoginService {

    private static final String KAKAO_CLIENT_ID = "0bd130ca58a4b6f05b9591f1c2240a42";
    private static final String KAKAO_REDIRECT_URI = "http://localhost:8888/tot/kakaocallback";
    private static final String KAKAO_CLIENT_SECRET = "cXc6jxYcuL3OdL1XGLcbvYAAtti4XYRa";

    public String getKakaoAuthUrl() {
        return "https://kauth.kakao.com/oauth/authorize?client_id=" + KAKAO_CLIENT_ID
                + "&redirect_uri=" + KAKAO_REDIRECT_URI + "&response_type=code";
    }

    public Map<String, Object> getKakaoUserInfo(String code) throws IOException {
        String kakaoTokenUrl = "https://kauth.kakao.com/oauth/token";
        RestTemplate restTemplate = new RestTemplate();

        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("grant_type", "authorization_code");
        params.add("client_id", KAKAO_CLIENT_ID);
        params.add("redirect_uri", KAKAO_REDIRECT_URI);
        params.add("code", code);
        params.add("client_secret", KAKAO_CLIENT_SECRET);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(params, headers);

        ResponseEntity<Map> response = restTemplate.exchange(kakaoTokenUrl, HttpMethod.POST, request, Map.class);
        String accessToken = (String) response.getBody().get("access_token");

        String kakaoUserInfoUrl = "https://kapi.kakao.com/v2/user/me";
        headers = new HttpHeaders();
        headers.setBearerAuth(accessToken);

        HttpEntity<String> userInfoRequest = new HttpEntity<>(headers);
        ResponseEntity<Map> userInfoResponse = restTemplate.exchange(kakaoUserInfoUrl, HttpMethod.GET, userInfoRequest, Map.class);
        
        Map<String, Object> userInfo = userInfoResponse.getBody();
        
        // 카카오 API에서 반환된 사용자 ID를 Long 타입에서 String으로 변환
        Long idAsLong = (Long) userInfo.get("id");
        String idAsString = String.valueOf(idAsLong);

        userInfo.put("id", idAsString);  // String으로 변환된 ID로 다시 저장
        

        // 이메일 정보 처리
        Map<String, Object> kakaoAccount = (Map<String, Object>) userInfo.get("kakao_account");
        String email = (String) kakaoAccount.get("email");
        if (email == null || email.isEmpty()) {
            email = "no-email@kakao.com";  // 이메일이 없을 경우 기본 이메일 설정
        }
        userInfo.put("email", email);  // 이메일 정보 저장
        
        return userInfo;
    }
}

