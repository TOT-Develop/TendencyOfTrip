package tot.dao;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import tot.domain.Member;

@Repository
public class MemberDaoImpl implements MemberDao {

    @Autowired
    private SqlSession sqlSession;

    private static final String NAMESPACE = "tot.dao.MemberDao.";
    
    @Override
    public void saveMember(Member member) {
        sqlSession.insert(NAMESPACE + "saveMember", member);
    }

    @Override
    public void updateNickname(Member member) {
        // MyBatis의 SQL 매퍼로 Member 객체 전달
        sqlSession.update(NAMESPACE + "updateNickname", member);
    }

    @Override
    public String findNicknameByMemId(String memId) {
        return sqlSession.selectOne(NAMESPACE + "findNicknameByMemId", memId);
    }

    @Override
    public String findNicknameByNick(String nickname) {
        return sqlSession.selectOne(NAMESPACE + "findNicknameByNick", nickname);
    }

    @Override
    public Member findMemberByMemId(String memId) {
        return sqlSession.selectOne(NAMESPACE + "findMemberByMemId", memId);
    }

    @Override
    public void updateMemberStatus(String memId, String memberStatus, Timestamp banStart, Timestamp banEnd) {
        // 파라미터로 전달할 객체 생성
        Map<String, Object> params = new HashMap<>();
        params.put("memId", memId);
        params.put("memberStatus", memberStatus);
        params.put("banStart", banStart);
        params.put("banEnd", banEnd);

        sqlSession.update(NAMESPACE + "updateMemberStatus", params);
    }
}
