window.onload = function() {
	$(".toListBtn").click(function(){
		window.location.href="adminQna.jsp";
	})
	
	
 const qnaid = sessionStorage.getItem('qnaid');
    fetch(`/tot/admin/qna/QnaDetail?QNAID=${qnaid}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok.');
            }
            return response.json();
        })
        .then(data => {
            console.log(data);
            $('.row2').html('');
            let QnaDetail = $(`
                <div class="qnaTitle">
                    <b>제목</b>
                    <p>${data.qnatitle}</p>
                </div>
                <div class="qnaTitleWriter">
                    <b>작성자</b>
                    <p>${data.memNick}</p>
                </div>
                <div class="qnaTitleContent">
                    <b>내용</b>
                    <p>${data.qnatext}</p>
                </div>
            `);
            $('.row2').append(QnaDetail);

            let commentForm = $(`
                <form id="commentForm">
                    <input type="hidden" name="qnaId" value="${data.qnaid}" />
                    <textarea name="commentText" id="commentText" rows="4" cols="50" placeholder="댓글을 입력하세요"></textarea>
                    <br />
                    <button type="submit">댓글 달기</button>
                </form>
            `);
            $('.row2').append(commentForm);

            // 댓글 작성 폼 제출 이벤트 처리
            $('#commentForm').submit(function(event) {
                event.preventDefault(); // 폼 제출 기본 동작 막기

                const qnaId = $('input[name="qnaId"]').val();
                const commentText = $('#commentText').val();

                $.ajax({
                    url: '/tot/admin/qna/addComment',
                    method: 'POST',
                    data: {
                        qnaId: qnaId,
                        commentText: commentText
                    },
                    success: function(response) {
                        alert(response); // 성공 메시지 출력
                        location.reload(); // 페이지 리로드
                    },
                    error: function(xhr, status, error) {
                        alert('Error: ' + xhr.responseText); // 에러 메시지 출력
                    }
                });
            });
        })
        .catch(error => console.error('Error:', error));
};