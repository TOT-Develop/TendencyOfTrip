package tot.oauth;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.social.google.connect.GoogleConnectionFactory;
import org.springframework.social.oauth2.AccessGrant;
import org.springframework.social.oauth2.GrantType;
import org.springframework.social.oauth2.OAuth2Operations;
import org.springframework.social.oauth2.OAuth2Parameters;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class GoogleLoginService {
	
    private final String clientId = "562781197218-3k94rslelo3rosi9aur4l68njse0832g.apps.googleusercontent.com";
    private final String clientSecret = "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";
    private final String redirectUri = "http://localhost:8888/tot/googlecallback";

    
    private GoogleConnectionFactory googleConnectionFactory;
    private OAuth2Parameters googleOAuth2Parameters;
    
    @PostConstruct
    public void init() {
        googleConnectionFactory = new GoogleConnectionFactory(clientId, clientSecret);
        googleOAuth2Parameters = new OAuth2Parameters();
        googleOAuth2Parameters.setScope("profile email");
        googleOAuth2Parameters.setRedirectUri(redirectUri);
    }    

    public String getGoogleAuthUrl() {
        OAuth2Operations oauthOperations = googleConnectionFactory.getOAuthOperations();
        return oauthOperations.buildAuthorizeUrl(GrantType.AUTHORIZATION_CODE, googleOAuth2Parameters);
    }

    public Map<String, String> getGoogleUserInfo(String code) throws IOException {
        OAuth2Operations oauthOperations = googleConnectionFactory.getOAuthOperations();
        AccessGrant accessGrant = oauthOperations.exchangeForAccess(code, googleOAuth2Parameters.getRedirectUri(), null);

        String accessToken = accessGrant.getAccessToken();
        String userInfoEndpoint = "https://www.googleapis.com/oauth2/v1/userinfo?access_token=" + accessToken;
        
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.getForObject(userInfoEndpoint, HashMap.class);
    }
}

