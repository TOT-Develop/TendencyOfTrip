package tot.dao;

import java.sql.Timestamp;
import tot.domain.Member;

public interface MemberDao {

    // 사용자 정보 저장
    void saveMember(Member member);

    // 사용자 닉네임 업데이트
    void updateNickname(Member member);

    // 사용자의 닉네임이 존재하는지 확인
    String findNicknameByMemId(String memId);

    // 닉네임 중복 체크
    String findNicknameByNick(String nickname);

    // MEMID로 사용자 정보 전체 조회
    Member findMemberByMemId(String memId);

    // 회원 상태와 제재 기간 업데이트
    void updateMemberStatus(String memId, String memberStatus, Timestamp banStart, Timestamp banEnd);
    
    
}
