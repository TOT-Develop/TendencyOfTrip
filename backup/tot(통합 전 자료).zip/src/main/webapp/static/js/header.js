$(document).ready(function() {

    // 닉네임 정규식 정의 (한글, 영문, 숫자, 2~10자)
    var nicknameRegex = /^[가-힣a-zA-Z0-9_]{2,10}$/;

    // 닉네임 변경 모달 열기
    window.showNicknameModal = function() {
        $("#nicknameModal").show();  // 모달 창을 표시
    };

    // 닉네임 변경 모달 닫기
    window.closeNicknameModal = function() {
        $("#nicknameModal").hide();  // 모달 창을 숨기기
    };

    // 닉네임 변경 폼 제출 처리
    $("#nicknameForm").submit(function(e) {
        e.preventDefault();  // 폼 기본 제출 동작 막기

        var newNickname = $("#newNickname").val();  // 입력된 닉네임 가져오기

        if (!newNickname) {
            alert("닉네임을 입력해주세요.");
            return;
        }
        
                // 닉네임 정규식 유효성 검사
        if (!newNickname) {
            alert("닉네임을 입력해주세요.");
            return;
        }

        if (!nicknameRegex.test(newNickname)) {
            alert("닉네임은 2~10자의 한글, 영문, 숫자만 사용할 수 있습니다.");
            return;
        }

        // AJAX 요청으로 닉네임 변경 처리
        $.ajax({
            url: contextPath + '/api/members/changeNickname',  // 닉네임 변경 요청 URL
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ newNickname: newNickname }),  // 입력된 닉네임을 서버로 전송
            success: function(response) {
                alert("닉네임이 변경되었습니다.");
                location.reload();  // 성공 시 페이지 새로고침
            },
            error: function(xhr) {
                if (xhr.status === 400) {
                    alert("중복된 닉네임입니다. 다른 닉네임을 입력해주세요.");
                } else {
                    alert("닉네임 변경에 실패했습니다.");
                }
            }
        });
    });
});
