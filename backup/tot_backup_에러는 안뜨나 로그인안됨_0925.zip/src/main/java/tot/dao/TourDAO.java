package tot.dao;

import tot.domain.TourVO;

public interface TourDAO {

	TourVO getTourById(String tourId);

}
