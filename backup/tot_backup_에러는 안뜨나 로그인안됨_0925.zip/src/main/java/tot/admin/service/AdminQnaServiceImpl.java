package tot.admin.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import tot.admin.dao.AdminQnaDao;
import tot.common.page.PageDTO;
import tot.common.page.PageReqDTO;
import tot.common.page.PageResDTO;
import tot.dao.QnaDao;
import tot.domain.Member;
import tot.domain.Qna;
import tot.domain.QnaComment;
import tot.exception.ServerException;

@Service
public class AdminQnaServiceImpl implements AdminQnaService {

	@Autowired
	private AdminQnaDao AdminqnaDao;
	
	@Override
	public List<Qna> qnaList() {
        return AdminqnaDao.qnaList();
	}
	
	@Override
	public Qna getQnaDetail(int QNAID) {
		return AdminqnaDao.getQnaDetail(QNAID);
	}

	@Override
	public int insertQna(Qna qna) {
		return AdminqnaDao.insertQna(qna);
	}

	@Override
	public Qna getQna(int QNAID) {
		return AdminqnaDao.getQna(QNAID);
	}
	
	@Override
    public String getMemNickByMemId(String memId) {
        return AdminqnaDao.getMemNickByMemId(memId);
    } 
	
	@Override
	public PageResDTO<Qna> findQnaListWithPaging(PageReqDTO pageReqDTO) throws Exception {
		try {		
			PageDTO pageDTO = new PageDTO(pageReqDTO);
			
		    int totalPostCount = AdminqnaDao.selectQnaTotalCount(pageDTO);
		    
		    List<Qna> qnaList = AdminqnaDao.qnaListWithPaging(pageDTO);
		    
		    return new PageResDTO<>(totalPostCount, pageReqDTO.getPage(), qnaList);
		} catch (DataAccessException e) {
            throw new ServerException("문의사항 목록을 가져오는 중 데이터베이스 오류 발생", e);
        } catch (Exception e) {
            // Exception 처리 (예외를 로깅하거나 다른 처리를 할 수 있음)
            throw new ServerException("알 수 없는 오류 발생", e); // 필요에 따라 구체적인 예외로 감싸서 던짐
        }
		
	}
	
	public List<Qna> findMyQnaList(String memId) {
	    return AdminqnaDao.getMyQnaList(memId);  // 
	    
    }
		
    @Override
    public List<Qna> findQnaListWithPagingByMemId(PageReqDTO dto, String memId) {
        return AdminqnaDao.qnaListWithPagingByMemId(dto, memId);  // memId가 있는 경우
    }
    
    @Override
    public int insertQnaComment(QnaComment qnaComment) {
        return AdminqnaDao.insertQnaComment(qnaComment);
    }
    
    @Override
    public List<QnaComment> getQnaComments(int qnaId) {
        return AdminqnaDao.getQnaComments(qnaId);
    }
	

//	@Override
//	public Member getMemberId(int MEMID) {
//		return qnaDao.getMemberId(MEMID);
//	}

}