package tot.oauth;

import static tot.common.Constants.*;

import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import tot.dao.MemberDao;
import tot.domain.Member;
import tot.exception.ErrorCode;
import tot.exception.ValidationException;
import tot.service.MemberService;
import tot.util.ValidationUtil;

/**
 * Handles requests for the application home page.
 */
@Controller
public class LoginController {
	
	@Autowired
	private MemberDao memberDao;
	
	@Autowired
	private MemberService memberService;

    @Autowired
    private NaverLoginService naverLoginService;

    @Autowired
    private GoogleLoginService googleLoginService;

    @Autowired
    private KakaoLoginService kakaoLoginService;

    @RequestMapping(value = "/login", method = { RequestMethod.GET, RequestMethod.POST })
    public String login(Model model, HttpSession session) {
    	System.out.println("login success");
        String naverAuthUrl = naverLoginService.getAuthorizationUrl(session);
        model.addAttribute("naver_url", naverAuthUrl);

        String googleAuthUrl = googleLoginService.getGoogleAuthUrl();
        model.addAttribute("google_url", googleAuthUrl);

        String kakaoAuthUrl = kakaoLoginService.getKakaoAuthUrl();
        model.addAttribute("kakao_url", kakaoAuthUrl);

        return "login";
    }
    
    @RequestMapping(value = "/navercallback", method = { RequestMethod.GET, RequestMethod.POST })
    public String naverCallback(@RequestParam String code, @RequestParam String state, HttpSession session, Model model, RedirectAttributes redirectAttributes )
            throws IOException {
        String accessToken = naverLoginService.getAccessToken(session, code, state);
        Map<String, Object> userInfo = naverLoginService.getUserProfile(accessToken);
        handleLogin(session, model, userInfo);
        
        String nickname = (String) session.getAttribute("nickname");
        if (nickname == null) {
            redirectAttributes.addFlashAttribute("loginSuccess", true);
            return "redirect:/login";
        } else {
            return "redirect:/jsp/main.jsp";
        }        

    }

    @RequestMapping(value = "/googlecallback", method = { RequestMethod.GET, RequestMethod.POST })
    public void simple() {
    	System.out.println("simple");
    }
//    public String googleCallback(@RequestParam String code, HttpSession session, Model model, RedirectAttributes redirectAttributes) throws IOException {
//    	System.out.println("googlecallback called");
//    	System.out.println("get callback code" + code);
//        Map<String, String> userInfo;
//        try {
//            userInfo = googleLoginService.getGoogleUserInfo(code);
//            System.out.println("User info: " + userInfo);
//        } catch (Exception e) {
//            e.printStackTrace();
//            throw new IOException("Failed to fetch user info from Google", e);
//        }
//
//        // 로그인 처리
//        handleLogin(session, model, userInfo);
//
//        // 닉네임 확인
//        String nickname = (String) session.getAttribute("nickname");
//        System.out.println("Session nickname: " + nickname);
//
//        if (nickname == null) {
//            // 신규 사용자일 경우 모달창을 띄우기 위해 loginSuccess 값을 전달
//            redirectAttributes.addFlashAttribute("loginSuccess", true);
//            return "redirect:/login";
//        } else {
//            return "redirect:/jsp/main.jsp";
//        }
//    }
  
    
    @RequestMapping(value = "/kakaocallback", method = { RequestMethod.GET, RequestMethod.POST })
    public String kakaoCallback(@RequestParam String code, HttpSession session, Model model, RedirectAttributes redirectAttributes) throws IOException {
        Map<String, Object> userInfo = kakaoLoginService.getKakaoUserInfo(code);
        handleLogin(session, model, userInfo);
        
        String nickname = (String) session.getAttribute("nickname");
        if (nickname == null) {
            // 신규 사용자라면 모달창을 띄우기 위해 loginSuccess 값을 전달
            redirectAttributes.addFlashAttribute("loginSuccess", true);
            return "redirect:/login";
        } else {
            return "redirect:/jsp/main.jsp";
        }
        
    }

    private void handleLogin(HttpSession session, Model model, Map<String, ?> userInfo) {
        String memId = (String) userInfo.get("id");
        String email = (String) userInfo.get("email");

        session.setAttribute("memId", memId);
        session.setAttribute("email", email);
        
        // 닉네임 존재 확인
        String nickname = memberDao.findNicknameByMemId(memId);

        if (nickname != null) {
            session.setAttribute("nickname", nickname);
            session.setAttribute("LoggedIn", true);

            // 기존 회원일 경우 Member 객체 생성 후 세션에 저장
            Member member = memberDao.findMemberByMemId(memId);
            session.setAttribute("member", member);  // Member 객체 전체 저장
        } else {
            model.addAttribute("loginSuccess", true);
        }
    }    

    
    @PostMapping("/saveNickname")
    public String saveNickname(@RequestParam("nickname") String nickname, HttpSession session, Model model) {
        String memId = (String) session.getAttribute("memId");
        String email = (String) session.getAttribute("email");

        try {
        	
        	// 닉네임 정규식 검사
        	ValidationUtil.validateNicknameFormat(nickname, ErrorCode.INVALID_NICKNAME_FORMAT);
        	
            // 닉네임 저장 및 중복 검사
            memberService.saveNickname(memId, nickname, email);

            // 회원 정보를 DB에서 가져와서 Member 객체로 생성
            Member member = memberDao.findMemberByMemId(memId);

            // 세션에 Member 객체 저장
            session.setAttribute("member", member);

            // 로그인 상태로 전환
            session.setAttribute("LoggedIn", true);

            return "redirect:/jsp/main.jsp";
        } catch (ValidationException e) {
            model.addAttribute("errorMessage", e.getErrorCode().getMessage());
            model.addAttribute("loginSuccess", true);
            return "login"; // 닉네임 모달창을 다시 띄움
        }
    }

}

