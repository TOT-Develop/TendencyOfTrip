package tot.oauth;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpSession;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class NaverLoginService {

    private static final String CLIENT_ID = "QycJLGZF1ZEf238dYGhT";
    private static final String CLIENT_SECRET = "CMxG15NwrP";
    private static final String REDIRECT_URI = "http://localhost:8888/tot/navercallback";
    private static final String NAVER_AUTH_URL = "https://nid.naver.com/oauth2.0/authorize";
    private static final String NAVER_TOKEN_URL = "https://nid.naver.com/oauth2.0/token";
    private static final String NAVER_PROFILE_URL = "https://openapi.naver.com/v1/nid/me";

    // 네이버 로그인 URL 생성
    public String getAuthorizationUrl(HttpSession session) {
        String state = generateRandomString();
        session.setAttribute("oauth_state", state);

        return NAVER_AUTH_URL + "?response_type=code&client_id=" + CLIENT_ID
                + "&redirect_uri=" + REDIRECT_URI + "&state=" + state;
    }

    // 액세스 토큰 요청
    public String getAccessToken(HttpSession session, String code, String state) throws IOException {
        if (!state.equals(session.getAttribute("oauth_state"))) {
            throw new IllegalStateException("Invalid OAuth state parameter");
        }

        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("grant_type", "authorization_code");
        params.add("client_id", CLIENT_ID);
        params.add("client_secret", CLIENT_SECRET);
        params.add("code", code);
        params.add("state", state);

        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(params, headers);

        ResponseEntity<String> response = restTemplate.exchange(NAVER_TOKEN_URL, HttpMethod.POST, request, String.class);

        // JSON 파싱하여 액세스 토큰 반환
        ObjectMapper mapper = new ObjectMapper();
        JsonNode rootNode = mapper.readTree(response.getBody());
        return rootNode.path("access_token").asText();
    }

    // 사용자 프로필 정보 가져오기
    public Map<String, Object> getUserProfile(String accessToken) throws IOException {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(accessToken);

        HttpEntity<String> request = new HttpEntity<>(headers);

        ResponseEntity<String> response = restTemplate.exchange(NAVER_PROFILE_URL, HttpMethod.GET, request, String.class);

        // 사용자 정보를 JSON으로 파싱
        ObjectMapper mapper = new ObjectMapper();
        JsonNode rootNode = mapper.readTree(response.getBody());

        Map<String, Object> userInfo = new HashMap<>();
        JsonNode responseNode = rootNode.path("response");
        userInfo.put("id", responseNode.path("id").asText());
        userInfo.put("email", responseNode.path("email").asText());

        return userInfo;
    }

    // 상태 토큰 생성을 위한 임의의 문자열 생성
    private String generateRandomString() {
        return UUID.randomUUID().toString();
    }
}

