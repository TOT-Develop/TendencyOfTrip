package tot.domain;

import java.sql.Timestamp;
import java.time.LocalDateTime;



public class QnaComment {
    private int qnacid;
    private int qnaid;
    private String qnactext;
    private Timestamp qnacregdate;
    private Timestamp qnaupdate;

    // 기본 생성자 추가
    public QnaComment() {
    }

    // 모든 필드를 초기화하는 생성자 (필요에 따라 추가)
    public QnaComment(int qnacid, int qnaid, String qnactext, Timestamp qnacregdate, Timestamp qnaupdate) {
        this.qnacid = qnacid;
        this.qnaid = qnaid;
        this.qnactext = qnactext;
        this.qnacregdate = qnacregdate;
        this.qnaupdate = qnaupdate;
    }

    // Getter와 Setter 메서드 추가
    public int getQnacid() {
        return qnacid;
    }

    public void setQnacid(int qnacid) {
        this.qnacid = qnacid;
    }

    public int getQnaid() {
        return qnaid;
    }

    public void setQnaid(int qnaid) {
        this.qnaid = qnaid;
    }

    public String getQnactext() {
        return qnactext;
    }

    public void setQnactext(String qnactext) {
        this.qnactext = qnactext;
    }

    public Timestamp getQnacregdate() {
        return qnacregdate;
    }

    public void setQnacregdate(Timestamp qnacregdate) {
        this.qnacregdate = qnacregdate;
    }

    public Timestamp getQnaupdate() {
        return qnaupdate;
    }

    public void setQnaupdate(Timestamp qnaupdate) {
        this.qnaupdate = qnaupdate;
    }
}
