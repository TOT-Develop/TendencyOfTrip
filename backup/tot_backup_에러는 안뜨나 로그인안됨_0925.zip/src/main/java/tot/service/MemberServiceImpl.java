package tot.service;

import java.sql.Timestamp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tot.dao.MemberDao;
import tot.domain.Member;
import tot.exception.ErrorCode;
import tot.exception.ValidationException;
import tot.util.ValidationUtil;

@Service
public class MemberServiceImpl implements MemberService {

    @Autowired
    private MemberDao memberDao;

    // 회원 저장 메서드
    @Override
    public void saveMember(String socialId, String nickname, String email) {
        Member member = new Member();
        member.setMemId(socialId);
        member.setMemNick(nickname);
        member.setMemEmail(email);
        member.setMemRegDate(new java.sql.Timestamp(System.currentTimeMillis()));

        System.out.println("Saving new member with ID: " + socialId + ", Nickname: " + nickname + ", Email: " + email);

        memberDao.saveMember(member);
    }
    
    // 회원 찾기
    @Override
    public Member findMemberByMemId(String memId) {
        return memberDao.findMemberByMemId(memId);
    }
    
    // 닉네임 저장 및 중복 검사
    @Override
    public void saveNickname(String memId, String nickname, String email) throws ValidationException {
        System.out.println("Checking nickname for memId: " + memId + ", Nickname: " + nickname + ", Email: " + email);
        
        // 닉네임 형식 검증
        ValidationUtil.validateNicknameFormat(nickname, ErrorCode.INVALID_NICKNAME_FORMAT);
        
        // 닉네임 중복 검증
        ValidationUtil.validateDuplicateNickname(nickname, memberDao, ErrorCode.DUPLICATE_NICKNAME);

        Member existingMember = memberDao.findMemberByMemId(memId);
        if (existingMember != null) {
            existingMember.setMemNick(nickname);
            memberDao.updateNickname(existingMember);
        } else {
            Member newMember = new Member();
            newMember.setMemId(memId);
            newMember.setMemNick(nickname);
            newMember.setMemEmail(email);
            newMember.setMemRegDate(new java.sql.Timestamp(System.currentTimeMillis()));
            memberDao.saveMember(newMember);
        }
    }

    // 닉네임 업데이트 메서드
    @Override
    public void updateNickname(String memId, String newNickname) throws ValidationException {
    	
    	// 닉네임 형식 검증
        ValidationUtil.validateNicknameFormat(newNickname, ErrorCode.INVALID_NICKNAME_FORMAT);
    	    	
    	// 닉네임 중복 검사
        ValidationUtil.validateDuplicateNickname(newNickname, memberDao, ErrorCode.DUPLICATE_NICKNAME);
        
        Member member = memberDao.findMemberByMemId(memId);
        if (member != null) {
            member.setMemNick(newNickname);
            memberDao.updateNickname(member);
        }
    }

    // 제재 상태 적용 메서드
    @Override
    public void applyBan(String memId, String banStatus) {
        long banPeriodDays = 0;
        switch (banStatus) {
            case "M02_1":
                banPeriodDays = 1;
                break;
            case "M02_2":
                banPeriodDays = 7;
                break;
            case "M02_3":
                banPeriodDays = 15;
                break;
            case "M02_4":
                banPeriodDays = 30;
                break;
        }

        Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
        Timestamp banEndTimestamp = new Timestamp(currentTimestamp.getTime() + banPeriodDays * 24 * 60 * 60 * 1000);

        memberDao.updateMemberStatus(memId, banStatus, currentTimestamp, banEndTimestamp);
    }


}
