package tot.service;

import tot.domain.Member;
import tot.exception.ValidationException;

public interface MemberService {
    void saveMember(String socialId, String nickname, String email);

    void updateNickname(String memId, String newNickname) throws ValidationException;

    void applyBan(String memId, String banStatus);

    void saveNickname(String memId, String nickname, String email) throws ValidationException;
    
    Member findMemberByMemId(String memId);
    
}
