package tot.service;

import tot.domain.TourVO;

public interface TourService {

	TourVO getTourById(String tourId);

}
